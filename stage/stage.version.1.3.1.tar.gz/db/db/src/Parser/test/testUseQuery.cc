#include<Parser/ParseQuery.h>


int main() {
// 		DataBase::ParseQuery parser();
}
