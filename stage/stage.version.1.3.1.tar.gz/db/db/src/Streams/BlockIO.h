#pragma once

namespace IO {

struct BlockIO {

};
}
