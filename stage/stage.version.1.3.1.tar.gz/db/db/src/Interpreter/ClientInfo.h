#pragma  once
#include<string>

namespace DataBase {

class ClientInfo {
public:
    std::string current_user;
};

}
