#include<Function/FunctionRegistry.h>


void DataBase::registerFunctions()
{

}

