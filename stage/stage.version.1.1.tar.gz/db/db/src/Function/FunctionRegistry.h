#pragma once

namespace DataBase {

void registerFunctions();

}
