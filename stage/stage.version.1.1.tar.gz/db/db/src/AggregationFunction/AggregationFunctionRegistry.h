#pragma once

namespace DataBase {

void registerAggregationFunctions();

}
