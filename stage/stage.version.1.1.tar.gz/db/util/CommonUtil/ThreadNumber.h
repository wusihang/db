#pragma once

//获取当前进程号
namespace ThreadUtil {
namespace ThreadNumber {
unsigned get();
}
}
