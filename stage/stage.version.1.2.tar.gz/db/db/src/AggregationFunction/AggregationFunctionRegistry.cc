#include<AggregationFunction/AggregationFunctionRegistry.h>


void DataBase::registerAggregationFunctions()
{

}
