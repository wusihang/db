#pragma once
#include<string>

namespace SystemUtil {
const std::string & getFQDNOrHostName();
}
